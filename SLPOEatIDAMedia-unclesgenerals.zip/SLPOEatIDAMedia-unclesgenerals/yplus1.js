console.log("aadd.abheaa");
console.log("25+1=26");
console.log("y+1=z");

console.log("ehd9pattonwilson_y+1=26");

// Assign values to x and y

let x = 1;
let y = 25;

// Add y + x and assign z the sum value

let z = y + x;

console.log(z);


// Subtract z - y and assign w the difference 

let w = y - z;

console.log(w);

// Subtract k - p and assign r the difference 

let k = 0.012345679;
let p = 0.12345679;

let r = k - p;

console.log(r);



