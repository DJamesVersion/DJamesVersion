#python 3.7.1

print ("53_0206027")
print ("NASP437721")

input ("please list your reasons for being able to use this program:")
print ("thank you, you reply is very much appreciated.")

input ("please tell me you are finished bothering yourself looking through these files:")
print ("there is only a reasoning for sanity, never loss...especially if what is inside us is much more important than what is outside us; though both in and out perception is syncopated and just and/or realized cognitively in a healthy manner ")

input ("please, y or n; are you sentient?")
print ("thank you, you may now end this program_thanks for being 46 chromosomes.")
