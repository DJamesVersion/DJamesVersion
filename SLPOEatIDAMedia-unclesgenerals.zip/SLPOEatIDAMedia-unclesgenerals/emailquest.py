print ("SLPOE@IDAMedia")

print ("JAMESPATTONWILSON")



print ("aadd.abheaa");




input("please give your email address:")
print ("To confirm, your email address is: tahkmahnelle@gmail.com")

print ("61158470686657_237417411437721")

print ("ehd9pattonwilson")